using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FrontEnd.Pages.Cliente
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
